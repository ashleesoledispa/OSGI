package com.example.greeter;

import com.example.clock.ClockService;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component(
        service = GreeterCommand.class,
        property = {
                "osgi.command.scope=greeter",
                "osgi.command.function=say"
        }
)
public class GreeterCommand {

    private volatile ClockService clockService;

    @Reference
    public void setClockService(ClockService clockService) {
        this.clockService = clockService;
    }

    public void unsetClockService(ClockService clockService) {
        if (this.clockService == clockService) {
            this.clockService = null;
        }
    }

    public void say(String name) {
        String hora = (clockService != null)
                ? clockService.getCurrentTime()
                : "desconocida (servicio ClockService no disponible)";

        System.out.println("Hola " + name + ", son las " + hora);
    }
}
