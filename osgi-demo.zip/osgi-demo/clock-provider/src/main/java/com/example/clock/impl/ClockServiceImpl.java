package com.example.clock.impl;

import com.example.clock.ClockService;
import org.osgi.service.component.annotations.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component(
        service = ClockService.class,
        immediate = true
)
public class ClockServiceImpl implements ClockService {

    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public String getCurrentTime() {
        return LocalDateTime.now().format(formatter);
    }
}
