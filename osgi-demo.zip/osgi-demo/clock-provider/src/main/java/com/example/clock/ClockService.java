package com.example.clock;

public interface ClockService {
    String getCurrentTime();
}
